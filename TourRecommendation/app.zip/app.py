from flask import Flask
from flask import request
import pymysql
from werkzeug.utils import secure_filename
import os

import json

app = Flask(__name__)

app.secret_key = 'any random string'

UPLOAD_FOLDER = 'static/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="tour_recommendation")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

"########################################################################################"     

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        
        username = request_data['username']
        email = request_data['email']
        mobile = request_data['mobile']
        password = request_data['password']
        
        cursor.execute('SELECT * FROM usertable WHERE username = %s', (username))
        count = cursor.rowcount
        if count == 1:            
            return "fail"
        else:        
            sql1 = "INSERT INTO usertable(username, email, mobile, password) VALUES (%s, %s, %s, %s);"
            val1 = (username, email, mobile, password)
            cursor.execute(sql1,val1)
            con.commit()        
            return "success"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        username = request_data['name']
        password = request_data['pass']
        
        cursor.execute('SELECT * FROM usertable WHERE username = %s AND password = %s', (username, password))
        count = cursor.rowcount
        if count == 1:            
            return "success"
        else:
            return "fail"
        
@app.route('/getProfile/<username>', methods=['GET', 'POST'])
def getProfile(username):
        
    cursor.execute('SELECT * FROM usertable WHERE username = %s',(username))
    row = cursor.fetchall() 
    
    jsonObj = json.dumps(row)
    print(jsonObj)
    
    return jsonObj
        
@app.route('/updateProfile', methods=['GET', 'POST'])
def updateProfile():
    if request.method == 'POST':
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        
        username = request_data['username']
        email = request_data['email']
        mobile = request_data['mobile']
        password = request_data['password']
        
        sql1 = "UPDATE usertable SET email = %s,mobile = %s,password = %s WHERE username = %s;"
        val1 = (email,mobile,password,username)
        cursor.execute(sql1,val1) 
        con.commit()        
        return "success"
        
"########################################################################################"  

    
if __name__ == "__main__":
    app.run("0.0.0.0")